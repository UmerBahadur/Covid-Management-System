/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package covidmanagementsystem;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;

public class City extends JFrame {

  // Declare GUI components
  private JLabel lblVaccineName;
  public static JComboBox cmbVaccineName;
  private JLabel lblQuantity;
  private JComboBox txtQuantity;
  private JButton btnOrder;
  private JButton btnLogout;
  private JTable tblOrders;
  private JScrollPane scrollPane;
private JButton btnback;
public String var;
  // Declare data model for table
  //private OrderTableModel tableModel;
  private VaccineTable tablemodel1;
 // public String[]it;
  public static ArrayList<String> arr;
  public City() {
      var=new String();
    // Set up GUI components
    LoginExample l1=new LoginExample();
    arr=new ArrayList<>();
    String []it={};  
    try {
           it=l1.getVaccines(1);
      } catch (SQLException ex) {
         JOptionPane.showMessageDialog(null, ex);
      }
    
    lblVaccineName = new JLabel("Vaccine Name:");
    cmbVaccineName = new JComboBox(it);
   // lblQuantity = new JLabel("Quantity:");
   String[]time={"10:00 am","12:00 pm","2:00 pm"};
    txtQuantity = new JComboBox(time);
    btnOrder = new JButton("Book appointment");
    btnLogout = new JButton("Exit");
    btnback =new JButton("back");
   

      try {
          // Set up table and data model
      
          tablemodel1=l1.getItems(1);
      } catch (SQLException ex) {
         JOptionPane.showMessageDialog(null, ex);
      }
    tblOrders = new JTable(tablemodel1);
    scrollPane = new JScrollPane(tblOrders);

    // Set up layout
    setLayout(new BorderLayout());
    JPanel pnlInput = new JPanel(new FlowLayout());
    pnlInput.add(lblVaccineName);
    pnlInput.add(cmbVaccineName);
    //pnlInput.add(lblQuantity);
    pnlInput.add(txtQuantity);
    pnlInput.add(btnOrder);
    pnlInput.add(btnLogout);
   // pnlInput.add(viewCart);
    pnlInput.add(btnback);
    add(pnlInput, BorderLayout.NORTH);
    add(scrollPane, BorderLayout.CENTER);

    // Set up event handlers
    btnback.addActionListener(e->back());
    btnOrder.addActionListener(e -> {
          try {
              bookAppointment();
          } catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, ex);
          } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, ex);
          }
      });
    btnLogout.addActionListener(e -> logout());
//    viewCart.addActionListener(e->cart());
  }
  private void bookAppointment() throws SQLException, ClassNotFoundException {
      
      
    String name = (String) cmbVaccineName.getSelectedItem();
    //int quantity = Integer.parseInt(txtQuantity.getText());
    LoginExample l1=new LoginExample();
    int price=0;
    for (int i = 0; i < tablemodel1.getRowCount(); i++) {
    for (int j = 0; j < tablemodel1.getColumnCount(); j++) {
        if (tablemodel1.getValueAt(i, 0).equals(name)) {
          price=(Integer)tablemodel1.getValueAt(i, 2);  
            break;
        }       
         }
if(removeVaccine()){
//          try {
//             // l1.updateSales(1, 1);
//          } catch (SQLException ex) {
//              Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
//          }
   // txtQuantity.setText("");      
      }
    
      }
    var+="Hospital : CityHospital\n";
    var+="Vaccine : "+name+"\n";
    var+="\nTime : "+txtQuantity.getSelectedItem().toString()+"\n";
    var+=l1.searchName(Module.userid);
    if(var.contains("Second")){
        l1.update(Module.userid, 2,name);
    var+="\nDose : Second\n";
    }
    else{
     var+="\nDose : First\n";
        l1.update(Module.userid, 1,name);
    }
    
    PatientSlip.text1+=var;
    PatientSlip ps=new PatientSlip();
    ps.setVisible(true);
      setVisible(false);
  }
private void back(){
    PatientPanel u1=new PatientPanel();
    u1.setVisible(true);
    setVisible(false);
}
  private void logout() {
    LoginPage manager = new LoginPage();
    manager.setVisible(true);
    setVisible(false);
  }
  
   private boolean removeVaccine() {
String s1=(String) cmbVaccineName.getSelectedItem();
    int selectedRow = 0;

for (int i = 0; i < tablemodel1.getRowCount(); i++) {
    for (int j = 0; j < tablemodel1.getColumnCount(); j++) {
        if (tablemodel1.getValueAt(i, 0).equals(s1)) {
            selectedRow = i;
            break;
        }
    }
}

    if (selectedRow != -1) {
       int quantity=Integer.parseInt(tablemodel1.getValueAt(selectedRow, 2).toString());
      String price1=(tablemodel1.getValueAt(selectedRow, 1).toString());
        if (quantity<2){
            JOptionPane.showMessageDialog(null, "Out of stock");
        }
        else{
            LoginExample l=new LoginExample();
         
         quantity-=1;
            try {
                l.updateItems(s1, quantity, 1);
            } catch (SQLException ex) {
              JOptionPane.showMessageDialog(null, ex);
            }
         Vaccine f1=new Vaccine(s1,price1 ,quantity);
          tablemodel1.addVaccine(f1);
         tablemodel1.removeVaccine(selectedRow);
        return true;
        }
        
      
    }
    return false;
  }
}

