/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package covidmanagementsystem;


import java.awt.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import java.util.ArrayList;

public class AdminCentral extends JFrame {

  // Declare GUI components
  private JLabel lblVaccineName;
  private JTextField txtVaccineName;
  private JLabel lblQuantity;
  private JLabel lblmanufacturer;
  private JTextField txtQuantity;
  private JTextField txtManufacturer;
  private JButton btnAdd;
  private JButton btnRemove;
  private JButton btnLogout;
  private JTable tblInventory;
  private JScrollPane scrollPane;
  private  JButton btnback;
  // Declare data model for table
  private VaccineTable tableModel;

  public AdminCentral() {
     // ImageIcon icon = new ImageIcon("C:\\Users\\noorm\\Downloads\\1.png");
    // Set up GUI components
    lblVaccineName = new JLabel("Vaccine:");
    txtVaccineName = new JTextField(20);
    lblQuantity = new JLabel("Quantity:");
    txtQuantity = new JTextField(20);
    lblmanufacturer=new JLabel("Manufacturer :");
    txtManufacturer=new JTextField(20);
    btnAdd = new JButton("Add");
    btnRemove = new JButton("Remove");
    btnLogout = new JButton("Logout");
    btnback=new JButton("back");
   // btnback.setIcon(icon);

    
    LoginExample l1=new LoginExample();
    
      try {
          // Set up table and data model
          tableModel =l1.getItems(1);
      } catch (SQLException ex) {
          Logger.getLogger(AdminCity.class.getName()).log(Level.SEVERE, null, ex);
      }
    tblInventory = new JTable(tableModel);
    scrollPane = new JScrollPane(tblInventory);

    // Set up layout
    setLayout(new BorderLayout());
    JPanel pnlInput = new JPanel(new FlowLayout());
    pnlInput.add(lblVaccineName);
    pnlInput.add(txtVaccineName);
    pnlInput.add(lblQuantity);
    pnlInput.add(txtQuantity);
    pnlInput.add(lblmanufacturer);
    pnlInput.add(txtManufacturer);
    pnlInput.add(btnAdd);
    pnlInput.add(btnRemove);
    pnlInput.add(btnLogout);
    pnlInput.add(btnback);
    add(pnlInput, BorderLayout.NORTH);
    add(scrollPane, BorderLayout.CENTER);

    // Set up event handlers
    btnAdd.addActionListener(e -> {
          try {
              addVaccine();
          } catch (SQLException ex) {
              Logger.getLogger(AdminCity.class.getName()).log(Level.SEVERE, null, ex);
          }
      });
    
    btnRemove.addActionListener(e -> removeVaccine());
    btnLogout.addActionListener(e -> logout());
    btnback.addActionListener(e->back());
    
  }

  private void addVaccine() throws SQLException {
    String name = txtVaccineName.getText();
    int quantity = Integer.parseInt(txtQuantity.getText());
    String man= (txtManufacturer.getText());
 int selectedRow=0;
 boolean v1=false;
    for (int i = 0; i < tableModel.getRowCount(); i++) {
    for (int j = 0; j < tableModel.getColumnCount(); j++) {
        if (tableModel.getValueAt(i, 0).equals(name)) {
            v1=true;
            selectedRow = i;
            
            break;
            
        }
    }
}
    if (v1){
        int q=Integer.parseInt(tableModel.getValueAt(selectedRow, 2).toString());
        man=tableModel.getValueAt(selectedRow, 1).toString();
        Vaccine vaccine = new Vaccine(name,man,quantity+q );
    tableModel.addVaccine(vaccine);
        txtManufacturer.setText("");
    txtVaccineName.setText("");
    txtQuantity.setText("");
    tableModel.removeVaccine(selectedRow);
       LoginExample l1=new LoginExample();
       l1.updateItems(name, quantity+q, 2);
    }
    else{
//    int q=Integer.parseInt(tableModel.getValueAt(selectedRow, 1).toString());
    Vaccine flower = new Vaccine(name,man,quantity);
     System.out.println(tableModel.getColumnCount());
    tableModel.addVaccine(flower);
   // User u1=new User();
    //User.cmbFlowerName.addItem(name);
    LoginExample l1=new LoginExample();
    l1.addItems(name, man,quantity,  2);
    txtManufacturer.setText("");
    txtVaccineName.setText("");
    txtQuantity.setText("");
    }
    }

  private void removeVaccine() {
String s1=txtVaccineName.getText();
    int selectedRow = tblInventory.getSelectedRow();
    int q=Integer.parseInt(txtQuantity.getText());
    //int price1=Integer.parseInt(txtManufacturer.getText());
//    
for (int i = 0; i < tableModel.getRowCount(); i++) {
    for (int j = 0; j < tableModel.getColumnCount(); j++) {
        if (tableModel.getValueAt(i, 0).equals(s1)) {
            selectedRow = i;
            break;
        }
    }
}

    if (selectedRow != -1) {
        String man  =(tableModel.getValueAt(selectedRow, 1).toString());
        int quantity=Integer.parseInt(tableModel.getValueAt(selectedRow, 2).toString());
        if (quantity<q){
            JOptionPane.showMessageDialog(null, "Error");
        }
        else{
            
         quantity-=q;
       //  tableModel.setValueAt(quantity, selectedRow, 2);
        Vaccine f1=new Vaccine(s1, man,quantity);
         tableModel.addVaccine(f1);
         tableModel.removeVaccine(selectedRow);
         LoginExample l=new LoginExample();
            try {
                l.updateItems(s1,quantity,2);
            } catch (SQLException ex) {
                Logger.getLogger(AdminCentral.class.getName()).log(Level.SEVERE, null, ex);
            }
          txtManufacturer.setText("");
    txtVaccineName.setText("");
    txtQuantity.setText("");
         //tableModel.setValueAt(quantity, selectedRow, 1);
        
        }
    }
  }
private void back(){
    AdminAcessPanel a1=new AdminAcessPanel();
     setVisible(false);
    a1.setVisible(true);
  
}
  private void logout() {
    LoginPage manager = new LoginPage();
    manager.setVisible(true);
    setVisible(false);
  }
}