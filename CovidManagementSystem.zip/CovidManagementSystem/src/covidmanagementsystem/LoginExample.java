/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package covidmanagementsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import javax.swing.JOptionPane;

public class LoginExample {

    public static int id = -1;
    Connection conn = null;
    Statement stmt = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    String name, pwd = null;

    public LoginExample() {

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            conn = DriverManager.getConnection("jdbc:ucanaccess://C:\\Users\\HP\\OneDrive\\Desktop\\Database3.accdb");
            JOptionPane.showMessageDialog(null, "Succesfull database Connection");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public void update(int id, int choice, String Vaccine) throws SQLException, ClassNotFoundException {
        if (choice == 1) {
            String var = "Done";
            String sql = "UPDATE Patient SET FirstDose='" + var + "',Vaccine='" + Vaccine + "' WHERE ID='" + id + "' ";
            pst = conn.prepareStatement(sql);
            int rs = pst.executeUpdate();
            if (rs > 0) {
                JOptionPane.showMessageDialog(null, "Successfully Updated");
            }
        } else if (choice == 2) {
            String var = "Done";
            String sql = "UPDATE Patient SET SecondDose ='" + var + "' WHERE ID='" + id + "'";
            pst = conn.prepareStatement(sql);
            int rs = pst.executeUpdate();
            if (rs > 0) {
                JOptionPane.showMessageDialog(null, "Successfully Updated");
            }

        }
    }

    public void addItems(String name, String man, int quantity, int choice) {
        if (choice == 1) {
            String sql = "insert into vaccine(Vaccine,Manufacturer,Quantity) values ('" + name + "','" + man + "','" + quantity + "')";
            try {
                stmt = conn.createStatement();

                int res = stmt.executeUpdate(sql);
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "Inserted");
                } else {
                    JOptionPane.showMessageDialog(null, "Error");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        }
        if (choice == 2) {
            String sql = "insert into vaccine2(Vaccine,Manufacturer,Quantity) values ('" + name + "','" + man + "','" + quantity + "')";
            try {
                stmt = conn.createStatement();

                int res = stmt.executeUpdate(sql);
                if (res > 0) {
                    JOptionPane.showMessageDialog(null, "Inserted");
                } else {
                    JOptionPane.showMessageDialog(null, "Error");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, ex);
            }
        }
    }

    public void adduser(String uname, String pass) {
        String sql = "insert into Patient(PatientName,Cnic) values ('" + uname + "','" + pass + "')";
        try {
            stmt = conn.createStatement();

            int res = stmt.executeUpdate(sql);
            if (res > 0) {
                JOptionPane.showMessageDialog(null, "Inserted");
            } else {
                JOptionPane.showMessageDialog(null, "Error");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    public VaccineTable getItems(int choice) throws SQLException {
        String name = new String();
        VaccineTable f1 = new VaccineTable();
        int Quantitiy;
        String Manufacturer;
        String var = new String();
        if (choice == 1) {
            String sql = "Select Vaccine,Manufacturer,Quantity from vaccine ";

            int counter = 0;

            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                name = rs.getString("Vaccine");
                Manufacturer = (rs.getString("Manufacturer"));
                Quantitiy = Integer.parseInt(rs.getString("Quantity"));

                Vaccine f = new Vaccine(name, Manufacturer, Quantitiy);
                f1.addVaccine(f);
                //pwd= rs.getString("Password");
            }
            if (name != null) {
                JOptionPane.showMessageDialog(null, "Search Successfull");
            } else {
                JOptionPane.showMessageDialog(null, "ERROR");
            }
        } else {
            String sql = "Select Vaccine,Manufacturer,Quantity from vaccine1 ";

            int counter = 0;

            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                name = rs.getString("Vaccine");
                Manufacturer = (rs.getString("Manufacturer"));
                Quantitiy = Integer.parseInt(rs.getString("Quantity"));

                Vaccine f = new Vaccine(name, Manufacturer, Quantitiy);
                f1.addVaccine(f);
            }
            if (name != null) {
                JOptionPane.showMessageDialog(null, "Search Successful");
            } else {
                JOptionPane.showMessageDialog(null, "ERROR");
            }

        }
        return f1;
    }

    public int search(String uname, String pass) throws SQLException {
        name = null;
        pwd = null;
        String sql = "Select ID from Login where Username ='" + uname + "' and Password ='" + pass + "' ";
        boolean b;

        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        while (rs.next()) {
            name = rs.getString("ID");
        }
        if (name != null) {
            JOptionPane.showMessageDialog(null, "Search Successful");
            return Integer.parseInt(name);
        } else {
            JOptionPane.showMessageDialog(null, "ERROR");
        }

        return -1;
    }

    void delete(int id) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM Login WHERE (ID) = ('" + id + "')";
        pst = conn.prepareStatement(sql);

        int rs = pst.executeUpdate();

    }

    public void updateItems(String name, int quantity, int choice) throws SQLException {
        if (choice == 1) {
            String sql = "UPDATE vaccine SET Quantity='" + quantity + "' WHERE Vaccine='" + name + "'";
            pst = conn.prepareStatement(sql);
            int rs = pst.executeUpdate();
            if (rs > 0) {
                JOptionPane.showMessageDialog(null, "Successfully Updated");
            }
        }
        if (choice == 2) {
            String sql = "UPDATE vaccine1 SET Quantity='" + quantity + "' WHERE Vaccine='" + name + "'";
            pst = conn.prepareStatement(sql);
            int rs = pst.executeUpdate();
            if (rs > 0) {
                JOptionPane.showMessageDialog(null, "Successfully Updated");
            }
        }
    }

    public String searchName(int id) throws SQLException {
        String sql = "Select Patientname,FirstDose,SecondDose from Patient where ID='" + id + "' ";
        String var = new String();
        int counter = 0;
        String var1 = new String();
        String var2 = new String();

        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        while (rs.next()) {
            var += "Patient name : " + (rs.getString("PatientName"));
            var1 = rs.getString("FirstDose");
            var2 = rs.getString("SecondDose");
        }
        if (var1 != null) {
            if (var2 != null) {
                var += "Both doses done";
            } else {
                var += "FirstDose : Done \nSecond Dose : Done ";

            }
        } else {
            var += "FirstDose : Done  ";
        }

        return var;
    }

    public int search(String cnic) throws SQLException {
        // String Cnic=new String();
        VaccineTable f1 = new VaccineTable();
        String sql = "Select ID from Patient where Cnic='" + cnic + "' ";

        int counter = 0;

        pst = conn.prepareStatement(sql);
        rs = pst.executeQuery();
        while (rs.next()) {
            id = Integer.parseInt(rs.getString("ID"));
        }

        return id;
    }

    public String[] getVaccines(int choice) throws SQLException {
        String[] arr = new String[20];
        if (choice == 1) {

            String sql = "Select Vaccine from vaccine  ";

            int counter = 0;

            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                arr[counter] = rs.getString("Vaccine");
                counter++;
            }
        } else {

            String sql = "Select Vaccine from vaccine1  ";

            int counter = 0;

            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while (rs.next()) {
                arr[counter] = rs.getString("Vaccine");
                counter++;
            }
        }
        return arr;
    }
}
