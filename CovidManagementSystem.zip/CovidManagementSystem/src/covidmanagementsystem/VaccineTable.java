/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package covidmanagementsystem;

import javax.swing.table.AbstractTableModel;
import java.util.List;
import java.util.ArrayList;

public class VaccineTable extends AbstractTableModel {

  // Declare column names and data
  private String[] columnNames = {"Vaccine", "Manufacturer","Quantitiy",""};
  private ArrayList<Vaccine> data = new ArrayList<>();

  @Override
  public int getRowCount() {
    return data.size();
  }

  @Override
  public int getColumnCount() {
    return columnNames.length;
  }

  @Override
  public String getColumnName(int column) {
    return columnNames[column];
  }

  @Override
  public Object getValueAt(int rowIndex, int columnIndex) {
    Vaccine v = data.get(rowIndex);
    if (columnIndex == 0) {
      return v.getName();
    } else if (columnIndex == 1) {
      return v.getManufacturer();
      
    } 
    else if (columnIndex==2){
    return v.getQuantity();
    }else {
      return null;
    }
  }
  public void addVaccine(Vaccine v) {
    data.add(v);
    fireTableRowsInserted(data.size() - 1, data.size() - 1);
  }

  public void removeVaccine(int rowIndex) {
    data.remove(rowIndex);
    fireTableRowsDeleted(rowIndex, rowIndex);
  }  
}
