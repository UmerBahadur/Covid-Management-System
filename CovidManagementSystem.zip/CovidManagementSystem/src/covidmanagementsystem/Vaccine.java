/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package covidmanagementsystem;

public class Vaccine {
  private String name;
  private String manufacturer;
  private int quantity;

  public Vaccine(String name, String manufacturer, int quantity) {
    this.name = name;
    this.manufacturer = manufacturer;
    this.quantity = quantity;
  }

  public String getName() {
    return name;
  }

  public String getManufacturer() {
    return manufacturer;
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }
}
